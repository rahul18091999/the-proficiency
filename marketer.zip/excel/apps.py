from django.apps import AppConfig


class ExcelConfig(AppConfig):
    name = 'excel'
