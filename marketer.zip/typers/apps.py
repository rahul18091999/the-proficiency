from django.apps import AppConfig


class TypersConfig(AppConfig):
    name = 'typers'
