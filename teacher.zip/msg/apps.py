from django.apps import AppConfig


class MsgConfig(AppConfig):
    name = 'msg'
