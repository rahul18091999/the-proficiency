from django.apps import AppConfig


class MarketerConfig(AppConfig):
    name = 'marketer'
