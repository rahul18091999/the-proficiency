from django.apps import AppConfig


class BannersConfig(AppConfig):
    name = 'banners'
