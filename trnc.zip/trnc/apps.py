from django.apps import AppConfig


class TrncConfig(AppConfig):
    name = 'trnc'
